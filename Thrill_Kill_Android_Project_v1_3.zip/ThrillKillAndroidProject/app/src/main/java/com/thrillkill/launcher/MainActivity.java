package com.thrillkill.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int GAME_PICKER_REQUEST = 7302;
    private static final String ASSET_HOST = "appassets.androidplatform.net";
    private static final String DUCKSTATION_PACKAGE = "com.github.stenzek.duckstation";
    private static final String PREFS = "thrill_kill_preferences";
    private static final String PREF_GAME_URI = "selected_game_uri";
    private static final String PREF_GAME_NAME = "selected_game_name";
    private static final String PREF_GAME_SIZE = "selected_game_size";

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        applyImmersiveMode();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setDefaultTextEncodingName("UTF-8");

        webView.addJavascriptInterface(new LauncherBridge(), "ThrillKillNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (ASSET_HOST.equals(uri.getHost()) && uri.getPath() != null && uri.getPath().startsWith("/assets/")) {
                    String assetPath = uri.getPath().substring("/assets/".length());
                    try {
                        InputStream stream = getAssets().open(assetPath);
                        String mime = URLConnection.guessContentTypeFromName(assetPath);
                        if (mime == null) {
                            if (assetPath.endsWith(".html")) mime = "text/html";
                            else if (assetPath.endsWith(".js")) mime = "application/javascript";
                            else if (assetPath.endsWith(".css")) mime = "text/css";
                            else if (assetPath.endsWith(".svg")) mime = "image/svg+xml";
                            else mime = "application/octet-stream";
                        }
                        String encoding = (mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json")) ? "UTF-8" : null;
                        return new WebResourceResponse(mime, encoding, stream);
                    } catch (IOException e) {
                        Log.e("ThrillKill", "Asset not found: " + assetPath, e);
                        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", Collections.emptyMap(),
                                new ByteArrayInputStream("Local asset not found".getBytes()));
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (ASSET_HOST.equals(uri.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                catch (Exception e) { Log.w("ThrillKill", "No app can open link", e); }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript("window.restoreNativeGameSelection && window.restoreNativeGameSelection();", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("https://" + ASSET_HOST + "/assets/index.html");
    }

    private Uri getSavedGameUri() {
        String value = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_GAME_URI, null);
        if (value == null || value.isEmpty()) return null;
        try { return Uri.parse(value); } catch (Exception e) { return null; }
    }

    private String getSavedGameName() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_GAME_NAME, "");
    }

    private long getSavedGameSize() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getLong(PREF_GAME_SIZE, 0L);
    }

    private void launchGamePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/octet-stream", "application/x-chd", "application/x-iso9660-image", "application/x-cue"
        });
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, GAME_PICKER_REQUEST);
    }

    private String queryDisplayName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (Exception ignored) {}
        String segment = uri.getLastPathSegment();
        return segment == null ? "Juego PS1" : segment;
    }

    private long queryFileSize(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.SIZE);
                if (index >= 0 && !cursor.isNull(index)) return cursor.getLong(index);
            }
        } catch (Exception ignored) {}
        return 0L;
    }

    private boolean isSupportedGameName(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        return lower.endsWith(".chd") || lower.endsWith(".iso") || lower.endsWith(".cue")
                || lower.endsWith(".bin") || lower.endsWith(".pbp") || lower.endsWith(".img");
    }

    private String mimeForGame(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".chd")) return "application/x-chd";
        if (lower.endsWith(".cue")) return "application/x-cue";
        if (lower.endsWith(".iso")) return "application/x-iso9660-image";
        return "application/octet-stream";
    }

    private void launchSavedGame() {
        Uri gameUri = getSavedGameUri();
        if (gameUri == null) {
            notifyJs("No has seleccionado el juego todavía.");
            return;
        }
        try {
            // Re-grant read access every time the saved document is handed to DuckStation.
            // DuckStation exposes this activity for an explicit launch. Its Android
            // EmulationActivity reads the "bootPath" intent extra before starting the core.
            Intent emulation = new Intent();
            emulation.setClassName(DUCKSTATION_PACKAGE,
                    DUCKSTATION_PACKAGE + ".EmulationActivity");
            emulation.putExtra("bootPath", gameUri.toString());
            emulation.setDataAndType(gameUri, mimeForGame(getSavedGameName()));
            emulation.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            emulation.setClipData(ClipData.newUri(getContentResolver(), "THRILL KILL game", gameUri));
            if (emulation.resolveActivity(getPackageManager()) != null) {
                startActivity(emulation);
                return;
            }
        } catch (Exception e) {
            Log.w("ThrillKill", "Could not send game to DuckStation", e);
        }
        showDuckStationRequiredDialog();
    }

    private void showDuckStationRequiredDialog() {
        new AlertDialog.Builder(this)
                .setTitle("DuckStation no está instalado")
                .setMessage("Para ejecutar el juego sin usar un motor web, instala la aplicación oficial DuckStation. THRILL KILL recordará el archivo que ya seleccionaste y volverá a compartirlo al abrir el juego. Después de instalar DuckStation, no tendrás que seleccionar el archivo otra vez.")
                .setNegativeButton("Ahora no", null)
                .setPositiveButton("Abrir página oficial", (dialog, which) -> {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://downloads.duckstation.org/android-testing/"))); }
                    catch (Exception e) { Log.e("ThrillKill", "Could not open DuckStation page", e); }
                })
                .show();
    }

    private void notifyJs(String message) {
        if (webView != null) webView.post(() -> webView.evaluateJavascript(
                "window.setNativeStatus && window.setNativeStatus(" + JSONObject.quote(message) + ");", null));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GAME_PICKER_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            String name = queryDisplayName(uri);
            if (!isSupportedGameName(name)) {
                notifyJs("Formato no reconocido. Selecciona CHD, ISO, CUE, BIN o PBP.");
                return;
            }
            try {
                int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                getContentResolver().takePersistableUriPermission(uri, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception e) {
                Log.w("ThrillKill", "Could not persist selected game permission", e);
            }
            long size = queryFileSize(uri);
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(PREF_GAME_URI, uri.toString())
                    .putString(PREF_GAME_NAME, name)
                    .putLong(PREF_GAME_SIZE, size)
                    .apply();
            if (webView != null) {
                String js = "window.onNativeGameSelected && window.onNativeGameSelected(" +
                        JSONObject.quote(name) + "," + size + ");";
                webView.post(() -> webView.evaluateJavascript(js, null));
            }
        }
    }

    private void applyImmersiveMode() {
        View decor = getWindow().getDecorView();
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decor.setSystemUiVisibility(flags);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersiveMode();
    }

    @Override public void onBackPressed() { super.onBackPressed(); }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("ThrillKillNative");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private class LauncherBridge {
        @JavascriptInterface public void pickGameFile() {
            runOnUiThread(() -> {
                try { launchGamePicker(); }
                catch (Exception e) { notifyJs("Android no pudo abrir el selector de juegos."); }
            });
        }
        @JavascriptInterface public void launchSavedGame() {
            runOnUiThread(MainActivity.this::launchSavedGame);
        }
        @JavascriptInterface public String getSavedGameName() { return MainActivity.this.getSavedGameName(); }
        @JavascriptInterface public long getSavedGameSize() { return MainActivity.this.getSavedGameSize(); }
        @JavascriptInterface public boolean hasSavedGame() { return getSavedGameUri() != null; }
    }
}
