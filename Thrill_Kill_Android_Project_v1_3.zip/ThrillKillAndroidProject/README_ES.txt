THRILL KILL ANDROID v1.3

Esta versión es un launcher local para Android. El menú incluye únicamente los apartados de Compatibilidad y la historia de cancelación. No hay editor de menú.

FUNCIONES
- Icono basado en la portada proporcionada.
- Menú local sin scripts ni motor descargados desde internet.
- Selector Android SAF.
- Guarda la URI seleccionada para no pedir el mismo archivo cada vez.
- Envía el archivo guardado a DuckStation mediante un Intent explícito a la actividad Android de emulación usando el extra bootPath y permiso temporal de lectura.
- Secciones Compatibilidad y Por qué se canceló THRILL KILL.

REQUISITO IMPORTANTE
DuckStation debe estar instalado como aplicación independiente. Esta APK no incluye ni modifica DuckStation. La APK Android beta oficial solicita que no se redistribuya y que se enlace a su página oficial: https://downloads.duckstation.org/android-testing/
La instalación/actualización inicial de DuckStation puede necesitar internet. Una vez instalada y con el juego/BIOS local, jugar es offline.

ALMACENAMIENTO
El launcher guarda el URI persistente devuelto por Android. Cada vez que se pulsa Iniciar, vuelve a conceder permiso de lectura al archivo a DuckStation. Si el proveedor de archivos revoca el acceso o el archivo se mueve/elimina, habrá que seleccionarlo otra vez.

BIOS
No se incluye BIOS. DuckStation puede solicitar que el usuario importe uno de su propiedad.

COMPILACION
Ejecuta ./gradlew assembleDebug con Android SDK instalado o usa GitHub Actions. El APK de salida será app/build/outputs/apk/debug/app-debug.apk.

LICENCIAS
Este launcher no contiene código ni bibliotecas DuckStation. DuckStation es un proyecto independiente: https://github.com/stenzek/duckstation
