THRILL KILL ANDROID v1.4 — ACTUALIZACIÓN VISUAL / PREVIEW

CAMBIOS DE ESTA VERSIÓN
- Estética hueso marfil con manchas y detalles carmesí; no usa estética vampírica/gótica de Drácula.
- Botón principal renombrado a INICIAR CAZA.
- Vista previa del mando PlayStation con cruceta, △ ○ × □ y botones laterales con acabado hueso/sangre.
- Selector de carátula independiente del icono Android. La selección se guarda mediante permiso SAF persistente.
- Perfiles Ahorro, Equilibrado y Rendimiento guardan la preferencia en el dispositivo.
- Selector de juego conserva la URI, nombre y tamaño elegidos.
- Se eliminó la llamada a DuckStation y el requisito de tener DuckStation instalado.

LIMITACIÓN IMPORTANTE
Esta v1.4 es una actualización del launcher y una vista previa de interfaz. No incluye todavía el núcleo PCSX-ReARMed ni un frontend Libretro funcional. El botón INICIAR CAZA informa de esta limitación; no intenta abrir DuckStation ni simula que el juego se ha iniciado. Los perfiles aún no envían cambios al motor, y los botones del mando son una previsualización, no entradas de juego activas.

INTEGRACIÓN DEL MOTOR (SIGUIENTE FASE)
PCSX-ReARMed es un núcleo Libretro con licencia GPLv2 y admite juegos PlayStation en CHD, ISO, CUE, BIN, PBP, IMG y otros formatos documentados. Para ejecutarlo dentro de esta APK hace falta un frontend Android Libretro (por ejemplo, basado en LibretroDroid), el núcleo compilado para la ABI del dispositivo y conectar vídeo, audio, entrada táctil y ciclo de vida. No basta con empaquetar el .so. Deben incluirse avisos de licencia y ofrecer el código fuente correspondiente al núcleo y a cualquier componente GPL distribuido.

GUARDADOS
El núcleo PCSX-ReARMed soporta SaveRAM (tarjeta de memoria) y estados. Aún no están conectados a esta aplicación porque el frontend del motor no está integrado.

BIOS Y JUEGO
No se incluye juego ni BIOS. El usuario debe aportar copias que tenga derecho a utilizar. PCSX-ReARMed puede recurrir a HLE si no hay BIOS compatible, con menor compatibilidad en algunos juegos.

COMPILACIÓN
Desde la carpeta del proyecto: ./gradlew assembleDebug
El archivo de workflow para la raíz del repositorio se entrega por separado como build-apk-v1_4.yml; debe guardarse en .github/workflows/build-apk.yml.

LICENCIAS Y FUENTES
PCSX-ReARMed: GPLv2. Documentación: https://docs.libretro.com/library/pcsx_rearmed/
API Libretro: https://www.libretro.com/index.php/api/
LibretroDroid: https://github.com/Swordfish90/LibretroDroid (GPL-3.0)
