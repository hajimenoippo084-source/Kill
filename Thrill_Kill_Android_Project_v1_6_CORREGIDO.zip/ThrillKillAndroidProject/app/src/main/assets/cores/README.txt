The GitHub Actions workflow downloads pcsx_rearmed_libretro_android.so.zip from the official Libretro Buildbot and places the extracted shared library in this folder before Gradle packaging.
