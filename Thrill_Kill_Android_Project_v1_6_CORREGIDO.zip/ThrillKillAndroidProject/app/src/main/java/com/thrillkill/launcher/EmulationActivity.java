package com.thrillkill.launcher;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;

import com.swordfish.libretrodroid.GLRetroView;
import com.swordfish.libretrodroid.GLRetroViewData;
import com.swordfish.libretrodroid.ShaderConfig;

/** Native PS1 screen backed by LibretroDroid + the PCSX-ReARMed Libretro core. */
public class EmulationActivity extends Activity implements LifecycleOwner {
    public static final String EXTRA_GAME_PATH = "game_path";
    public static final String EXTRA_GAME_TITLE = "game_title";
    private static final String TAG = "ThrillKillEmu";
    private View retroView;
    private FrameLayout root;
    private LifecycleRegistry lifecycleRegistry;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        lifecycleRegistry = new LifecycleRegistry(this);
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        applyImmersive();

        String gamePath = getIntent().getStringExtra(EXTRA_GAME_PATH);
        String gameTitle = getIntent().getStringExtra(EXTRA_GAME_TITLE);
        if (gamePath == null || !new File(gamePath).isFile()) {
            Toast.makeText(this, "No se encontró el archivo del juego.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);
        try {
            retroView = createRetroView(gamePath);
            if (retroView == null) throw new IllegalStateException("LibretroDroid no devolvió la pantalla de emulación");
            lifecycleRegistry.addObserver((GLRetroView) retroView);
            retroView.setFocusable(true);
            retroView.setFocusableInTouchMode(true);
            root.addView(retroView, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            addGameControls();
            root.post(() -> { if (retroView != null) retroView.requestFocus(); });
            Log.i(TAG, "PCSX-ReARMed initialized for " + gamePath);
        } catch (Throwable error) {
            Log.e(TAG, "Could not initialize PCSX-ReARMed", error);
            Toast.makeText(this, "No se pudo iniciar el motor PS1: " + shortMessage(error), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private View createRetroView(String gamePath) throws Exception {
        if (!hasArm64()) throw new IllegalStateException("Este motor requiere Android ARM64.");

        File coreDir = new File(getFilesDir(), "cores");
        File systemDir = new File(getFilesDir(), "system");
        File saveDir = new File(getFilesDir(), "saves/pcsx-rearmed");
        if (!coreDir.exists() && !coreDir.mkdirs()) throw new IllegalStateException("No se pudo crear la carpeta del núcleo");
        if (!systemDir.exists() && !systemDir.mkdirs()) throw new IllegalStateException("No se pudo crear la carpeta del sistema");
        if (!saveDir.exists() && !saveDir.mkdirs()) throw new IllegalStateException("No se pudo crear la carpeta de guardados");

        File coreFile = new File(coreDir, "pcsx_rearmed_libretro_android.so");
        copyCoreAsset(coreFile);

        // LibretroDroid 0.13.2 uses GLRetroView(Context, GLRetroViewData),
        // not the old six-argument constructor used by the previous launcher.
        GLRetroViewData data = new GLRetroViewData(this);
        data.setCoreFilePath(coreFile.getAbsolutePath());
        data.setGameFilePath(gamePath);
        data.setSystemDirectory(systemDir.getAbsolutePath());
        data.setSavesDirectory(saveDir.getAbsolutePath());
        data.setShader(ShaderConfig.LCD.INSTANCE);

        return new GLRetroView(this, data);
    }

    private void copyCoreAsset(File destination) throws Exception {
        try (InputStream input = getAssets().open("cores/pcsx_rearmed_libretro_android.so");
             FileOutputStream output = new FileOutputStream(destination, false)) {
            byte[] buffer = new byte[64 * 1024];
            int count;
            while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            output.flush();
        }
        if (!destination.isFile() || destination.length() < 100_000) {
            throw new IllegalStateException("El núcleo PCSX-ReARMed no está incluido en la APK");
        }
    }

    private boolean hasArm64() {
        for (String abi : android.os.Build.SUPPORTED_ABIS) if ("arm64-v8a".equals(abi)) return true;
        return false;
    }

    private void addGameControls() {
        // Controls exist only in this gameplay Activity, never in the launcher menu.
        addShoulderControls();
        addDpad();
        addFaceButtons();
        addCenterControls();
        TextView exit = createButton("SALIR", 12, 68, 34);
        FrameLayout.LayoutParams exitParams = new FrameLayout.LayoutParams(dp(72), dp(38), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        exitParams.setMargins(0, dp(12), 0, 0);
        root.addView(exit, exitParams);
        exit.setOnClickListener(v -> finish());
    }

    private void addShoulderControls() {
        addControl("L2", KeyEvent.KEYCODE_BUTTON_L2, Gravity.TOP | Gravity.START, 12, 12, 48, 36, 12);
        addControl("L1", KeyEvent.KEYCODE_BUTTON_L1, Gravity.TOP | Gravity.START, 64, 12, 48, 36, 12);
        addControl("R1", KeyEvent.KEYCODE_BUTTON_R1, Gravity.TOP | Gravity.END, 64, 12, 48, 36, 12);
        addControl("R2", KeyEvent.KEYCODE_BUTTON_R2, Gravity.TOP | Gravity.END, 12, 12, 48, 36, 12);
    }

    private void addDpad() {
        GridLayout grid = new GridLayout(this);
        grid.setRowCount(3);
        grid.setColumnCount(3);
        addGridButton(grid, "▲", KeyEvent.KEYCODE_DPAD_UP, 0, 1);
        addGridButton(grid, "◀", KeyEvent.KEYCODE_DPAD_LEFT, 1, 0);
        addGridButton(grid, "▶", KeyEvent.KEYCODE_DPAD_RIGHT, 1, 2);
        addGridButton(grid, "▼", KeyEvent.KEYCODE_DPAD_DOWN, 2, 1);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(dp(150), dp(150), Gravity.BOTTOM | Gravity.START);
        params.setMargins(dp(7), 0, 0, dp(22));
        root.addView(grid, params);
    }

    private void addFaceButtons() {
        GridLayout grid = new GridLayout(this);
        grid.setRowCount(3);
        grid.setColumnCount(3);
        addGridButton(grid, "△", KeyEvent.KEYCODE_BUTTON_Y, 0, 1);
        addGridButton(grid, "□", KeyEvent.KEYCODE_BUTTON_X, 1, 0);
        addGridButton(grid, "○", KeyEvent.KEYCODE_BUTTON_B, 1, 2);
        addGridButton(grid, "×", KeyEvent.KEYCODE_BUTTON_A, 2, 1);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(dp(154), dp(154), Gravity.BOTTOM | Gravity.END);
        params.setMargins(0, 0, dp(7), dp(18));
        root.addView(grid, params);
    }

    private void addCenterControls() {
        TextView select = createButton("SELECT", 10, 62, 34);
        TextView start = createButton("START", 10, 62, 34);
        FrameLayout.LayoutParams selectParams = new FrameLayout.LayoutParams(dp(66), dp(34), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        selectParams.setMargins(0, 0, dp(76), dp(42));
        FrameLayout.LayoutParams startParams = new FrameLayout.LayoutParams(dp(66), dp(34), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        startParams.setMargins(dp(76), 0, 0, dp(42));
        root.addView(select, selectParams);
        root.addView(start, startParams);
        bindTouch(select, KeyEvent.KEYCODE_BUTTON_SELECT);
        bindTouch(start, KeyEvent.KEYCODE_BUTTON_START);
    }

    private void addControl(String label, int keyCode, int gravity, int horizontalMargin,
                            int topMargin, int width, int height, int textSize) {
        TextView button = createButton(label, textSize, width, height);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(dp(width), dp(height), gravity);
        if ((gravity & Gravity.HORIZONTAL_GRAVITY_MASK) == Gravity.RIGHT) params.setMargins(0, dp(topMargin), dp(horizontalMargin), 0);
        else params.setMargins(dp(horizontalMargin), dp(topMargin), 0, 0);
        root.addView(button, params);
        bindTouch(button, keyCode);
    }

    private void addGridButton(GridLayout grid, String label, int keyCode, int row, int column) {
        TextView button = createButton(label, 19, 48, 48);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams(
                GridLayout.spec(row), GridLayout.spec(column));
        params.width = dp(50);
        params.height = dp(50);
        params.setMargins(dp(1), dp(1), dp(1), dp(1));
        grid.addView(button, params);
        bindTouch(button, keyCode);
    }

    private TextView createButton(String label, int textSize, int width, int height) {
        TextView button = new TextView(this);
        button.setText(label);
        button.setTextColor(Color.rgb(112, 18, 25));
        button.setTextSize(textSize);
        button.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        button.setGravity(Gravity.CENTER);
        button.setBackground(new BoneBloodDrawable());
        button.setClickable(true);
        button.setFocusable(false);
        button.setElevation(dp(3));
        return button;
    }

    private void bindTouch(TextView button, int keyCode) {
        button.setOnTouchListener((view, event) -> {
            int action = event.getActionMasked();
            if (action == android.view.MotionEvent.ACTION_DOWN) {
                button.setPressed(true);
                sendButton(keyCode, true);
                return true;
            }
            if (action == android.view.MotionEvent.ACTION_UP || action == android.view.MotionEvent.ACTION_CANCEL) {
                button.setPressed(false);
                sendButton(keyCode, false);
                return true;
            }
            return true;
        });
    }

    private void sendButton(int keyCode, boolean down) {
        View target = retroView;
        if (target instanceof GLRetroView) {
            // LibretroDroid 0.13.2 expects action, key code and player port.
            ((GLRetroView) target).sendKeyEvent(
                    down ? KeyEvent.ACTION_DOWN : KeyEvent.ACTION_UP,
                    keyCode,
                    0
            );
        }
    }

    private void applyImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private String shortMessage(Throwable error) {
        Throwable cause = error;
        while (cause.getCause() != null) cause = cause.getCause();
        String message = cause.getMessage();
        return message == null ? cause.getClass().getSimpleName() : message;
    }

    @Override public Lifecycle getLifecycle() {
        return lifecycleRegistry;
    }

    @Override protected void onStart() {
        super.onStart();
        if (lifecycleRegistry != null) lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START);
    }

    @Override protected void onResume() {
        super.onResume();
        if (retroView instanceof GLRetroView) ((GLRetroView) retroView).onResume();
        if (lifecycleRegistry != null) lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME);
    }

    @Override protected void onPause() {
        if (lifecycleRegistry != null) lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE);
        if (retroView instanceof GLRetroView) ((GLRetroView) retroView).onPause();
        super.onPause();
    }

    @Override protected void onStop() {
        if (lifecycleRegistry != null) lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP);
        super.onStop();
    }

    @Override protected void onDestroy() {
        if (lifecycleRegistry != null) lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY);
        super.onDestroy();
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersive();
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (retroView != null && event.getSource() != InputDevice.SOURCE_UNKNOWN) {
            return retroView.dispatchKeyEvent(event) || super.onKeyDown(keyCode, event);
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (retroView != null && event.getSource() != InputDevice.SOURCE_UNKNOWN) {
            return retroView.dispatchKeyEvent(event) || super.onKeyUp(keyCode, event);
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override public void onBackPressed() { finish(); }

    /** Bone-coloured pad caps with non-graphic crimson speckles. */
    private static final class BoneBloodDrawable extends Drawable {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private boolean pressed;
        @Override public void draw(Canvas canvas) {
            RectF bounds = new RectF(getBounds());
            float cx = bounds.centerX(), cy = bounds.centerY();
            float radius = Math.min(bounds.width(), bounds.height()) * 0.45f;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(pressed ? Color.rgb(151, 18, 28) : Color.rgb(235, 225, 201));
            canvas.drawCircle(cx, cy, radius, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(2f, radius * 0.10f));
            paint.setColor(Color.rgb(102, 12, 20));
            canvas.drawCircle(cx, cy, radius - paint.getStrokeWidth() / 2f, paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(pressed ? Color.rgb(245, 231, 207) : Color.rgb(153, 22, 31));
            float dot = Math.max(1.7f, radius * 0.075f);
            canvas.drawCircle(cx - radius * .48f, cy - radius * .20f, dot, paint);
            canvas.drawCircle(cx + radius * .44f, cy + radius * .28f, dot * .72f, paint);
            canvas.drawCircle(cx + radius * .18f, cy - radius * .52f, dot * .54f, paint);
        }
        @Override protected boolean onStateChange(int[] state) {
            boolean next = false;
            for (int item : state) if (item == android.R.attr.state_pressed) next = true;
            if (next != pressed) { pressed = next; invalidateSelf(); }
            return true;
        }
        @Override public boolean isStateful() { return true; }
        @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); invalidateSelf(); }
        @Override public void setColorFilter(android.graphics.ColorFilter filter) { paint.setColorFilter(filter); invalidateSelf(); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }
}
